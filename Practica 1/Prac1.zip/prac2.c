#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>


int compara(const void *p1, const void *p2)
{
	float *num1, *num2;
	num1 = (float *) p1;
	num2 = (float *) p2;
	if (*num1 < *num2)
		return 1;
	else if (*num1 > *num2)
		return -1;
	else
		return 0;
}

int main(void)
{

	FILE *fp;
	char str[100];


	/* opening file for reading */
	fp = fopen("dades/float.txt" , "r");
	if(fp == NULL)
	{
		perror("Error opening file");
		return(-1);
	}
	if( fgets (str, 100, fp)!=NULL )
	{
		/* writing content to stdout */
		puts(str);
	}

	int SIZE = atoi(str);
	float *listFloats = malloc(SIZE*sizeof(float));

	for(int i=0; i < SIZE; i++){
		if( fgets (str, 100, fp)!=NULL )
		{
			/* writing content to stdout */
			puts(str);

			listFloats[i] = atof(str);
		}
	}
	/*
	for(int i=0; i < SIZE; i++){
			printf("%.6f", listFloats[i]);
			printf("\n");
	}
	*/

	fclose(fp);

	qsort(listFloats, SIZE, sizeof(float), compara);

	
	for(int i=0; i < SIZE; i++){
			printf("%f", listFloats[i]);
			printf("\n");
	}
	
	return 0;
}