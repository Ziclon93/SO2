#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>


int compara(const void *p1, const void *p2)
{
	int *num1, *num2;
	num1 = (int *) p1;
	num2 = (int *) p2;
	if (*num1 < *num2)
		return -1;
	else if (*num1 > *num2)
		return 1;
	else
		return 0;
}



int main(void)
{

	FILE *fp;
	char str[100];


	/* opening file for reading */
	fp = fopen("dades/integers.txt" , "r");
	if(fp == NULL)
	{
		perror("Error opening file");
		return(-1);
	}
	if( fgets (str, 100, fp)!=NULL )
	{
		/* writing content to stdout */
		puts(str);
	}

	int SIZE = atoi(str);
	int *listInts = malloc(SIZE*sizeof(int));

	for(int i=0; i < SIZE; i++){
		if( fgets (str, 100, fp)!=NULL )
		{
			/* writing content to stdout */
			puts(str);

			listInts[i] = atoi(str);
		}
	}

	/*
	for(int i=0; i < SIZE; i++){
			printf("%d", listInts[i]);
			printf("\n");
		}
	*/
	fclose(fp);

	qsort(listInts, SIZE, sizeof(int), compara);

	for(int i=0; i < SIZE; i++){
			printf("%d", listInts[i]);
			printf("\n");
	}

	free(listInts);

	return 0;
}