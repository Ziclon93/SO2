#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>


int compara(const void *p1, const void *p2)
{
	char *string1, *string2;
	int num1, num2;
	string1 = *((char**) p1);
	string2 = *((char**) p2);

	num1 = strlen(string1);
	num2 = strlen(string2);

	if (num1 < num2)
		return -1;
	else if (num1 > num2)
		return 1;
	else
		return 0;
}

int main(void)
{

	FILE *fp;
	char str[100];

	/* opening file for reading */
	fp = fopen("dades/strings.txt" , "r");
	if(fp == NULL)
	{
		perror("Error opening file");
		return(-1);
	}
	if( fgets (str, 100, fp)!=NULL )
	{
		/* writing content to stdout */
		puts(str);
	}

	int SIZE = atoi(str);

	char**listStrings = malloc(SIZE*sizeof(char*));

	for(int i=0; i < SIZE; i++){
		if( fgets (str, 100, fp)!=NULL )
		{
			/* writing content to stdout */
			puts(str);

			listStrings[i] = malloc(strlen(str) * sizeof(char));
			strcpy(listStrings[i],str);
			/*
			for(int o=0; o< strlen(str); o++){
				listStrings[i][o] = str[o];
			}
			*/


		}
	}

	/*
	for(int i=0; i < SIZE; i++){
			printf("%s", listStrings[i]);
			printf("\n");
	}
	*/

	fclose(fp);
	qsort(listStrings, SIZE, sizeof(char*), compara);

	for(int i=0; i < SIZE; i++){
			printf("%s", listStrings[i]);

			free(listStrings[i]);
			printf("\n");
	}

	free(listStrings);
	return 0;
}